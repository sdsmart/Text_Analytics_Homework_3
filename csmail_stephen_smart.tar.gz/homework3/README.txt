Name: Stephen Smart
ID#: 113851356

Email Extraction Programming Assignment

To populate the database I first created a python script that would download all of the files from
the cs mail website given, extract, and combine all of those files into one text file.
(email-extraction.py)

I used this text file (named email-data.txt) as the input to another python script that
created the sqlite database, processed the email text data, and populated the database using
built in python sqlite functions.
(email-processing.py)
